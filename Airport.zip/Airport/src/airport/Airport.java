package airport;
//This code adds passengers to a queue with the ability to view which passengers are in the queue, delete passengers, store passengers and load the file of passengers. 
//It can also run a simulation which adds a random number of passengers from a file in a random order and assigns a random queue time which increases everytime another passenger is added. 
//In each iteration another passenger is removed until there are no passengers left in the queue.
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Airport {

    static final int QUEUE_SIZE = 20;
    static Passenger[] passengersArray = new Passenger[30];
    static PassengerQueue passengerQueue = new PassengerQueue(QUEUE_SIZE);

    public static void main(String[] args) throws IOException, InterruptedException {

        initialise(passengersArray);
        Scanner in = new Scanner(System.in);
        String choice;

        do {

            System.out.println("A:to Add passengers to the boarding queue");
            System.out.println("V:to View the passengers in the queue");
            System.out.println("D:to Delete passengers from the queue");
            System.out.println("S:to Store Passenger data in to a file");
            System.out.println("L:to Load data from file to program");
            System.out.println("R:to Run the simulation and produce report");
            System.out.println("X:to Exit the program");
            String input = in.next().toUpperCase();
            choice = input;
            while (!choice.matches("[aAvVdDsSlLrRxX]")) {
                System.out.println("Invalid Input: Choose one of the following");
                System.out.println("A:to Add passengers to the boarding queue");
                System.out.println("V:to View the passengers in the queue");
                System.out.println("D:to Delete passengers from the queue");
                System.out.println("S:to Store Passenger data in to a file");
                System.out.println("L:to Load data from file to program");
                System.out.println("R:to Run the simulation and produce report");
                System.out.println("X:to Exit the program");
                choice = in.next().toUpperCase();
            }

            switch (choice) {
                case "A":
                    passengerQueue.add();
                    break;
                case "V":
                    passengerQueue.view();
                    break;
                case "D":
                    passengerQueue.remove();
                    break;
                case "S":
                    passengerQueue.store();
                    break;
                case "L":
                    passengerQueue.load();
                    break;
                case "R":
                    loadDat();
                    passengerQueue.runSim();
                    break;
                case "X":
                    System.exit(0);
            }
        } while (!choice.equals("x"));

    }

    public static void loadDat() throws InterruptedException {
        System.out.println("Simulation starting...");
        passengerQueue.time();
        int lineCount = 0;
        try (Scanner rf = new Scanner(new BufferedReader(new FileReader("C:\\Users\\uzuma\\Documents\\Uni Work\\Year 1\\Programming principles 2 assignment 2\\Airport\\passengers(7).dat")))) {
            String fileLine;
            while (rf.hasNext()) {
                fileLine = rf.nextLine();
                String passengerHash[] = fileLine.split(" ");
                passengersArray[lineCount] = new Passenger();
                passengersArray[lineCount].setfName(passengerHash[0]);
                passengersArray[lineCount].setsName(passengerHash[1]);
                System.out.println(passengersArray[lineCount].getfName() + " " + passengersArray[lineCount].getsName());
                lineCount++;
            }

        } catch (IOException e) {
            System.out.println("Error IOException is: " + e);
        }

    }

    private static void initialise(Passenger[] passengersArray) {
        for (int i = 0; i < passengersArray.length; i++) {
            passengersArray[i] = new Passenger();
            passengersArray[i].setfName("empty");
            passengersArray[i].setsName("empty");
            passengersArray[i].setSecondsInQueue(0);
        }
    }
}
