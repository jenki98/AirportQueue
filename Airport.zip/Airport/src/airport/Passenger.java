package airport;

public class Passenger {

    String fName;
    String sName;
    int secInQueue;

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getfName() {
        return fName;
    }

    public void setsName(String sName) {
        this.sName = sName;
    }

    public String getsName() {
        return sName;
    }

    public void setSecondsInQueue(int secInQueue) {
        this.secInQueue = secInQueue;
    }

    public int getSecondsInQueue() {
        return secInQueue;
    }

}
