package airport;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public final class PassengerQueue {

    Scanner in = new Scanner(System.in);
    int first = 0;
    int last = 0;
    int size = 0;
    static final int QUEUE_SIZE = 5;
    Passenger[] queueArray = new Passenger[QUEUE_SIZE];

    public PassengerQueue(int QUEUE_SIZE) {

        initialise(queueArray);

    }

    public void initialise(Passenger[] queueArray) {
        for (int i = 0; i < queueArray.length; i++) {
            queueArray[i] = new Passenger();
            queueArray[i].setfName("empty");
            queueArray[i].setsName("empty");
        }

    }

    public void add() {

        if (isFull()) {
            System.out.println("Queue is full");
        } else {
            String input;
            System.out.println("Enter First Name");
            input = in.next().toUpperCase();
            queueArray[last].setfName(input);
            while (!input.matches("[a-zA-Z,]+")) {
                System.out.println("Invalid");
                System.out.println("Enter Firstname");
                input = in.next().toUpperCase();
                queueArray[last].setfName(input);
            }

            System.out.println("Enter Surname");
            input = in.next().toUpperCase();
            queueArray[last].setsName(input);
            while (!input.matches("[a-zA-Z]+")) {
                System.out.println("Invalid");
                input = in.next().toUpperCase();
                queueArray[last].setsName(input);
            }

            System.out.println(queueArray[last].fName + " " + queueArray[last].sName + " added to queue");

            last = (last + 1) % queueArray.length;
            size++;
        }

    }

    public void remove() {
        if (!isEmpty()) {
            System.out.println("Passenger removed: " + queueArray[first].getfName() + " " + queueArray[first].getsName());
            queueArray[first].fName = "empty";
            queueArray[first].sName = "empty";
            first = (first + 1) % queueArray.length;
            size--;
        } else {
            System.out.println("Empty");
        }
    }

    public void view() {
        if (isEmpty()) {
            System.out.println("Empty Queue!! No data to view");
        } else {
            for (int i = 0; i < queueArray.length; i++) {
                System.out.println(queueArray[i].getfName() + " " + queueArray[i].getsName());
            }
        }

    }

    public void store() throws IOException {
        BufferedWriter outputWriter;
        outputWriter = null;

        outputWriter = new BufferedWriter(new FileWriter("myFile1.txt"));
        for (int i = 0; i < queueArray.length; i++) {
            outputWriter.write(queueArray[i].getfName() + " " + queueArray[i].getsName() + " ");
            outputWriter.newLine();
        }
        outputWriter.flush();
        outputWriter.close();

    }

    public void load() throws IOException {
        int lineCount = 0;
        try (Scanner rf = new Scanner(new BufferedReader(new FileReader("C:\\Users\\uzuma\\Documents\\Programming principles 2 assignment 2\\Airport\\myFile1.txt")))) {
            String fileLine;
            while (rf.hasNext()) {
                fileLine = rf.nextLine();
                String passengerHash[] = fileLine.split(" ");
                queueArray[lineCount].setfName(passengerHash[0]);
                queueArray[lineCount].setsName(passengerHash[1]);
                System.out.println(queueArray[lineCount].getfName() + " " + queueArray[lineCount].getsName());
                lineCount++;

            }
        } catch (IOException e) {
            System.out.println("Error IOException is: " + e);
        }

    }

    public boolean isFull() {
        boolean full = false;
        if (size == queueArray.length) {
            full = true;
        }
        return full;

    }

    public boolean isEmpty() {
        boolean empty = false;
        if (size == 0) {
            empty = true;
        }
        return empty;

    }

    public static void time() throws InterruptedException {
        TimeUnit.SECONDS.sleep(2);

    }

    public static int rdm() {
        return (int) (1 + 6 * Math.random());
    }

    public void viewSimArray(Passenger[] passengersQueue) {
        for (int i = 0; i < passengersQueue.length; i++) {
            System.out.println(passengersQueue[i].getfName() + " " +passengersQueue[i].getsName() + " Processing Delay: "+ passengersQueue[i].getSecondsInQueue() + "(s)");
        }

    }

    public void storeSim(int maxLength, int maxTime, int minWait, int avgTime) throws IOException {

        BufferedWriter outputWriter;
        outputWriter = null;
        outputWriter = new BufferedWriter(new FileWriter("report.dat"));
        for (int i = 0; i < Airport.passengersArray.length; i++) {
            outputWriter.write("First Name: " + Airport.passengersArray[i].getfName() + " Last Name: " + Airport.passengersArray[i].getsName() + " Processing Delay: " + Integer.toString(Airport.passengersArray[i].getSecondsInQueue()) + "(s)");
            outputWriter.newLine();
        }
        outputWriter.write("Report Summary: \n\n" + "Maximum length of Queue: " + maxLength + " Passengers\n" + "Maximum waiting time: " + maxTime + "(s)\n" + "Minimum waiting time: " + minWait
                + "(s)\n" + "Average waiting time: " + avgTime + "(s)");
        outputWriter.flush();
        outputWriter.close();

    }

    public void initialiseQueue(Passenger[] passengersQueue) {

        for (int i = 0; i < passengersQueue.length; i++) {
            passengersQueue[i] = new Passenger();
            passengersQueue[i].setfName("empty");
            passengersQueue[i].setsName("empty");
            passengersQueue[i].setSecondsInQueue(0);
        }

    }

    public void runSim() throws IOException, InterruptedException {
        int first = 0;
        int last = 0;
        int size = 0;
        int delay;
        int maxLength = 0;
        int minWait = 0;
        int avgTime = 0;
        int count = 0;
        int passengerNum;
        int firstDice;
        int secondDice;
        int thirdDice;
        int maxTime = 0;
        int pointer = 0;
        int length = 0;
        int totalDelay = 0;
        Passenger[] passengersQueue = new Passenger[30];
        initialiseQueue(passengersQueue);
        time();
        System.out.println();
        int remainder = 0;

        do {

            firstDice = rdm();
            secondDice = rdm();
            thirdDice = rdm();
            delay = firstDice + secondDice + thirdDice;

            passengerNum = rdm();
            if (length < Airport.passengersArray.length) {
                if ((pointer + passengerNum) < Airport.passengersArray.length) {
                    System.out.println(passengerNum + " Passengers have entered queue");
                    for (int i = 0; i < passengerNum; i++) {
                        passengersQueue[last].setfName(Airport.passengersArray[pointer + i].getfName());
                        passengersQueue[last].setsName(Airport.passengersArray[pointer + i].getsName());
                        System.out.println(passengersQueue[last].fName + " " + passengersQueue[last].sName + " Has entered Queue" + " Processing Delay: " + delay + "(s)");
                        last++;
                        size++;
                        length++;
                    }

                    pointer = pointer + passengerNum;

                } else {
                    remainder = pointer - Airport.passengersArray.length;
                    pointer = Airport.passengersArray.length - remainder;
                    for (int j = 0; j < remainder; j++) {
                        passengersQueue[last].setfName(Airport.passengersArray[pointer + j].getfName());
                        passengersQueue[last].setsName(Airport.passengersArray[pointer + j].getsName());

                        System.out.println(remainder + " Passengers have been added");
                        System.out.println(Airport.passengersArray[pointer + j].fName + " " + Airport.passengersArray[pointer + j].sName + " Processing Delay: " + delay + "(s)");
                        last++;
                        size++;
                        length++;
                    }
                }
            }
            if (size != 0) {
                for (int x = 0; x < passengersQueue.length; x++) {
                    if (!passengersQueue[x].fName.equals("empty")) {
                        Airport.passengersArray[x].setSecondsInQueue(Airport.passengersArray[x].secInQueue + delay);
                        passengersQueue[x].setSecondsInQueue(Airport.passengersArray[x].secInQueue);
                    }
                }
            }

            time();

            System.out.println("View Queue");

            time();

            System.out.println();

            viewSimArray(passengersQueue);

            System.out.println();

            time();
            if (Airport.passengersArray.length > first) {
                System.out.println("Passenger " + passengersQueue[first].getfName() + " " + passengersQueue[first].getsName() + " has boarded");
                passengersQueue[first].fName = "empty";
                passengersQueue[first].sName = "empty";
                passengersQueue[first].secInQueue = 0;
                first++;
                size--;

            }
            time();

            System.out.println();
            time();

            totalDelay = totalDelay + delay;
            if (totalDelay > maxTime) {
                maxTime = totalDelay;
            }
            count = count + 1;
            avgTime = totalDelay / count;
            minWait = delay;
            if (delay > minWait) {
                minWait = delay;
            }
            if (size >= 0) {
                if (size > maxLength) {
                    maxLength = size;
                }
            }

        } while (size != 0);

        storeSim(maxLength, maxTime, minWait, avgTime);
        display(maxLength, maxTime, minWait, avgTime);

    }

    private void display(int maxLength, int maxTime, int minWait, int avgTime) {
        System.out.println("Report: ");
        for (int x = 0; x < Airport.passengersArray.length; x++) {
            System.out.println(Airport.passengersArray[x].getfName() + " " + Airport.passengersArray[x].getsName() + " Processing Delay: " + Airport.passengersArray[x].getSecondsInQueue() + "(s)");
        }
        System.out.println("Report Summary:\n\n" + "Maximum length of Queue: " + maxLength + "\n" + "Maximum waiting time: " + maxTime + "(s)\n" + "Minimum waiting time: " + minWait + "(s)\n" + "Average waiting time:  " + avgTime);

    }
}
